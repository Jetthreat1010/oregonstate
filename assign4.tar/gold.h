#include <iostream>
#include <string>
#include <cstring>
#include <cstdlib>
#include <cmath>
#include <ctime>
#include <stdlib.h>

#ifndef GOLD_H
#define GOLD_H
#include "event.h"

using namespace std;

class Gold : public Event {
	public:
		virtual string percepts() override;
};

#endif
