#include <iostream>
#include <string>
#include <cstring>
#include <cstdlib>
#include <cmath>
#include <ctime>
#include <stdlib.h>

#include "bats.h"

using namespace std;

/************************************************************
 ** Function:percepts
 ** Description:returns percept of event
 ** Parameters:none
 ** Pre-Conditions:none
 ** Post-Conditions:returns percept of event
 ***********************************************************/
string Bats::percepts() {
	return "You hear wings flapping";
}

