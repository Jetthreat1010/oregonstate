#include <iostream>
#include <string>
#include <cstring>
#include <cstdlib>
#include <cmath>
#include <ctime>
#include <stdlib.h>

#ifndef ROOM_H
#define ROOM_H

#include "event.h"

class Room {
	private:
		int event_num;
		Event* eptr;
	public:
		Room();
		Room(const Room&);
		Room& operator=(const Room&);
		~Room();
		void set_event(int);
		void get_percepts();
		int get_event();
};

#endif
