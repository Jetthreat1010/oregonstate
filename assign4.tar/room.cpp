/******************************************************
 * ** Program: room.cpp
 * ** Author: Lawson Dietz
 * ** Date: 11/25/2019
 * ** Description:room class to store events and create a room
 * ** Input:none
 * ** Output: give according event back to prog
 * ******************************************************/
#include <iostream>
#include <string>
#include <cstring>
#include <cstdlib>
#include <cmath>
#include <ctime>
#include <stdlib.h>

#include "room.h"
#include "wumpus.h"
#include "bats.h"
#include "gold.h"
#include "pit.h"

Room::Room() {
	event_num = 0;
	eptr = NULL;	
}

Room::Room(const Room& r) {
	this->event_num = r.event_num;
	this->eptr = r.eptr;
}

Room& Room::operator=(const Room& r) {
	this->event_num = r.event_num;
	this->eptr = r.eptr;
}

Room::~Room() {
	delete eptr;
}

/************************************************************
 ** Function:set_event
 ** Description:sets event based on parameters
 ** Parameters:int 
 ** Pre-Conditions: int between 0 to 4
 ** Post-Conditions:eptr is filled respectively
 ***********************************************************/
void Room::set_event(int num) {
	event_num = num;
	if(event_num == 0) {
		delete eptr;
		eptr = NULL;
	}
	if(event_num == 1) {
		eptr = new Bats;
	}
	else if(event_num == 2) { 
		eptr = new Pit;
	}
	else if(event_num == 3) {
		eptr = new Gold;
	}
	else if(event_num == 4) {
		eptr = new Wumpus;
	}
}

/************************************************************
 ** Function:get_percepts
 ** Description:returns percept of eptr
 ** Parameters:none
 ** Pre-Conditions:none
 ** Post-Conditions:percepts called
 ***********************************************************/
void Room::get_percepts() {
	cout << eptr->percepts() << endl;
}

/************************************************************
 ** Function:get_event
 ** Description:returns event
 ** Parameters:none
 ** Pre-Conditions:none
 ** Post-Conditions:returns event
 ***********************************************************/
int Room::get_event() {
	return this->event_num;
}



