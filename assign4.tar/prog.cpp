/******************************************************
 * ** Program: prog.cpp
 * ** Author: Lawson Dietz
 * ** Date: 11/25/2019
 * ** Description:driver function to run game hunt the wumpus
 * ** Input:none
 * ** Output: Print to screen
 * ******************************************************/
#include <iostream>
#include <string>
#include <cstring>
#include <cstdlib>
#include <cmath>
#include <ctime>
#include <stdlib.h>
#include <vector>
#include <algorithm>
#include <curses.h>

#include "prog.h"

using namespace std;

int main(int argcc, char* argv[]) {
	srand(time(NULL));
	int gridSize = atoi(argv[1]), arrows = 3;
	char* debug = argv[2];
	string debugV2 = debug;
	vector<int> x,y;
	bool alive = true, gold = false, winCondition = false;
	string comp = "true";

	while(gridSize < 4 ) {
		gridSize = notInt();
	}
	createVectorCoords(x, y, gridSize);
	vector< vector<Room> > rooms(gridSize);
	fillVector(rooms, gridSize);
	populateEvents(x, y, gridSize, rooms);
	while(alive) {
		if(debugV2 == "true")
			printScreen(gridSize, x, y);
		else 
			printScreenRegular(gridSize, x, y);
		keyPress(x, y, gridSize, rooms, arrows);
		checkCoordinates(x, y, rooms, alive, gold, gridSize);
		checkPercepts(x, y, rooms, gridSize);
		if(winCondition = win(x, y, gold)) {
			cout << "Congratulations, you have found the treasure and made it out alive!" << endl;
			break;
		}
	}
}


/************************************************************
 ** Function:notInt
 ** Description:called when user enters a non integer value when it was supposed to be an int value
 ** Parameters:none
 ** Pre-Conditions:none
 ** Post-Conditions:integer value is returned to where called
 ***********************************************************/
int notInt() {
	int x = 0;
	cout << "Error not integer value, or out of range value entered: ";
	cin.clear();
	cin.ignore(1000, '\n');
	cin >> x;
	return x;
}

/************************************************************
 ** Function:fillVector
 ** Description:fills 2d vector with rooms
 ** Parameters:vector<vector<Room>> &, int
 ** Pre-Conditions:values initialized
 ** Post-Conditions:vector filled with rooms
 ***********************************************************/
void fillVector(vector<vector<Room>> &rooms, int gridSize) {
	for(int i = 0; i < gridSize; i++) {
		rooms[i] = vector<Room>(gridSize);
		for(int j = 0; j < gridSize; j++) {
			rooms[i].push_back(Room());
		}
	}
}

/************************************************************
 ** Function:win
 ** Description:gives win condition
 ** Parameters:vector<int> &, vector<int> &l bool &
 ** Pre-Conditions:variables initialized
 ** Post-Conditions:true/false
 ***********************************************************/
bool win(vector<int> &x, vector<int> &y, bool &gold) {
	if(gold) 
		if(x[0] == x[7] && y[0] == y[7])
			return true;
	return false;
}


/************************************************************
 ** Function:arrowW
 ** Description:fires arrow up
 ** Parameters: vector<int> &x, vector<int> &y, vector<vector<Room>> &rooms, int gridSize
 ** Pre-Conditions:variables initialized
 ** Post-Conditions:returns whether wumpus hit
 ***********************************************************/
bool arrowW(vector<int> &x, vector<int> &y, vector<vector<Room>> &rooms, int gridSize) {
	for(int i = 1; i <= 3; i++) {
		if((x[0] - i) >= 0) {
			if(rooms[x[0] - i][y[0]].get_event() == 4) {
				rooms[x[0] - i][y[0]].set_event(0);
				x[4] = -20;
				x[4] = -20;
				cout << "You hear the wumpus screech in pain, its been hit in the heart!" << endl;
				return true;
			}
		}
	}
	return false;
}

/************************************************************
 ** Function:arrowA
 ** Description:fires arrow left
 ** Parameters: vector<int> &x, vector<int> &y, vector<vector<Room>> &rooms, int gridSize
 ** Pre-Conditions:variables initialized
 ** Post-Conditions:returns whether wumpus hit
 ***********************************************************/
bool arrowA(vector<int> &x, vector<int> &y, vector<vector<Room>> &rooms, int gridSize) {
	for(int i = 1; i <= 3; i++) {
		if((y[0] - i) >= 0) {
			if(rooms[x[0]][y[0] - i].get_event() == 4) {
				rooms[x[0]][y[0] - i].set_event(0);
				x[4] = -20;
				y[4] = -20;
				cout << "You hear the wumpus screech in pain, its been hit in the heart!" << endl;
				return true;
			}
		}
	}
	return false;
}

/************************************************************
 ** Function:arrowS
 ** Description:fires arrow down
 ** Parameters: vector<int> &x, vector<int> &y, vector<vector<Room>> &rooms, int gridSize
 ** Pre-Conditions:variables initialized
 ** Post-Conditions:returns whether wumpus hit
 ***********************************************************/
bool arrowS(vector<int> &x, vector<int> &y, vector<vector<Room>> &rooms, int gridSize) {
	for(int i = 1; i <= 3; i++) {
		if((x[0] + i) < gridSize) {
			if(rooms[x[0] + i][y[0]].get_event() == 4) {
				rooms[x[0] + i][y[0]].set_event(0);
				x[4] = -20;
				x[4] = -20;
				cout << "You hear the wumpus screech in pain, its been hit in the heart!" << endl;
				return true;
			}
		}
	}
	return false;
}

/************************************************************
 ** Function:arrowD
 ** Description:fires arrow right
 ** Parameters: vector<int> &x, vector<int> &y, vector<vector<Room>> &rooms, int gridSize
 ** Pre-Conditions:variables initialized
 ** Post-Conditions:returns whether wumpus hit
 ***********************************************************/
bool arrowD(vector<int> &x, vector<int> &y, vector<vector<Room>> &rooms, int gridSize) {
	bool hit;
	for(int i = 1; i <= 3; i++) {
		if((y[0] + i) < gridSize) {
			if(rooms[x[0]][y[0] + i].get_event() == 4) {
				rooms[x[0]][y[0] + i].set_event(0);
				x[4] = -20;
				y[4] = -20;
				cout << "You hear the wumpus screech in pain, its been hit in the heart!" << endl;
				return true;
			}
		}
	}
	return false;
}

/************************************************************
 ** Function:arrow
 ** Description:fires an arrow in a given direction
 ** Parameters:vector<int> &, vector<int> &, vector<vector<Room>> &, int
 ** Pre-Conditions:variables initialized
 ** Post-Conditions:arrow is fired in given direction killing/moving wumpus
 ***********************************************************/
void arrow(vector<int> &x, vector<int> &y, vector<vector<Room>> &rooms, int gridSize) {
	char direction = returnDirection(1);
	bool control = false;
	int num = rand() % 4;
	if(direction == 'w') {
		control = arrowW(x, y, rooms, gridSize);
	}
	else if(direction == 'a') {
		control = arrowA(x, y, rooms, gridSize);
	}
	else if(direction == 's') {
		control = arrowS(x, y, rooms, gridSize);
	}
	else if(direction == 'd') {
		control = arrowD(x, y, rooms, gridSize);
	}
	if(!control){
		if(num <= 3) {
			cout <<"You hear the faint sounds of footsteps in another cave" << endl;
			moveWumpus(x, y, gridSize, rooms);
		}
	}
}

/************************************************************
 ** Function:moveWumpus
 ** Description:moves wumpus after missing arrow
 ** Parameters:vector<int> &, vector<int> &, int, vector<vector<Room>> &
 ** Pre-Conditions:variables initialized
 ** Post-Conditions:moves wumpus to new location
 ***********************************************************/
void moveWumpus(vector<int> &x, vector<int> &y, int gridSize, vector<vector<Room>> &rooms) {
	int num1, num2, count = 0;
	bool control = true;
	while(control) {
		num1 = generateRandom(gridSize);
		num2 = generateRandom(gridSize);
		for(int i = 0; i < 7; i++) {
			if((num1 == x[i]) && (num2 == y[i])) {
				count++;
			}
		}
		if(count == 0) {
			rooms[x[4]][y[4]].set_event(0);
			x[4] = num1;
			y[4] = num2;
			rooms[x[4]][y[4]].set_event(4);
			control = false;
		}
		count = 0;
	}
}

/************************************************************
 ** Function:batsRandom
 ** Description:moves player to random room
 ** Parameters:vector<int> &, vector<int> &, int
 ** Pre-Conditions:variables initialized
 ** Post-Conditions:players location is updated
 ***********************************************************/
void batsRandom(vector<int> &x, vector<int> &y, int gridSize) {
	int num1, num2;
	num1 = rand() % gridSize;
	num2 = rand() % gridSize;
	x[0] = num1;
	y[0] = num2;
}

/************************************************************
 ** Function:checkCoordinates
 ** Description:checks players current location for encounters
 ** Parameters:vector<int> &, vector<int> &, vector<vector<Room>> &, bool &, bool &, int
 ** Pre-Conditions:variables initialized
 ** Post-Conditions:players location triggers effects
 ***********************************************************/
void checkCoordinates(vector<int> &x, vector<int> &y, vector<vector<Room>> &rooms, bool &alive, bool &gold, int gridSize) {
	if(rooms[x[0]][y[0]].get_event() == 1) {
		//BATS	
		cout << "A storm of bats carries you to a random room, hope it wasn't the wumpus' room!" << endl;
		batsRandom(x, y, gridSize);
		checkCoordinates(x, y, rooms, alive, gold, gridSize);
	}	
	else if(rooms[x[0]][y[0]].get_event() == 2) {
		//PIT
		alive = false;
		cout << "You find yourself falling at 9.8m/s^2!" << endl;

	}	
	else if(rooms[x[0]][y[0]].get_event() == 3) {
		//GOLD
		gold = true;
		cout << "You found a sack of shiny coins! Now find the exit" << endl;
		rooms[x[0]][y[0]].set_event(0);
		x[3] = -2;
		y[3] = -2;
	}	
	else if(rooms[x[0]][y[0]].get_event() == 4) {
		//WUMPUS
		alive = false;
		cout << "You hear the Wumpus wake up but are too slow to evade him!" << endl;
	}	
}	

/************************************************************
 ** Function:checkPercepts
 ** Description:checks percepts in rooms adjacent to player
 ** Parameters:vector<int> &, vector<int> &, vector<vector<Room>> &, int
 ** Pre-Conditions:variables initialized
 ** Post-Conditions:percepts around player checked
 ***********************************************************/
void checkPercepts(vector<int> &x, vector<int> &y, vector<vector<Room>> &rooms, int gridSize) {
	if((x[0]- 1) >= 0) {
		if(rooms[x[0] - 1][y[0]].get_event() > 0) {
			rooms[x[0] - 1][y[0]].get_percepts();
		}
	}
	if((x[0]+ 1) < gridSize) {
		if(rooms[x[0] + 1][y[0]].get_event() > 0) {
			rooms[x[0] + 1][y[0]].get_percepts();
		}
	}
	if((y[0]- 1) >= 0) {
		if(rooms[x[0]][y[0] - 1].get_event() > 0) {
			rooms[x[0]][y[0] - 1].get_percepts();
		}
	}
	if((y[0] + 1) < gridSize) {
		if(rooms[x[0]][y[0] + 1].get_event() > 0) {
			rooms[x[0]][y[0] + 1].get_percepts();
		}
	}
}

/************************************************************
 ** Function:createVectorCoords
 ** Description:creates specific location for events and player starting position
 ** Parameters:vector<int> &, vector<int> &, int
 ** Pre-Conditions:variables initialized
 ** Post-Conditions: 7 unique coordinates created including one duplicate which is start position
 ***********************************************************/
void createVectorCoords(vector<int> &x, vector<int> &y, int gridSize) {
	int x_c, y_c, count = 0;
	bool control = false;
	for(int i = 0; i < 6; i++) {
		while(control == false) {
			x_c = generateRandom(gridSize);
			y_c = generateRandom(gridSize);
			if(x.size() >= 1) {
				for(int j = 0; j < x.size(); j++) {
					if((x_c != x[j] || y_c != y[j])) {
						count++;
					}	
				}
			}
			else {
				x.push_back(x_c);
				y.push_back(y_c);
				//Player coordinates
			}
			if(count == (x.size())) {
				x.push_back(x_c);
				y.push_back(y_c);
				control = true;
				// Other coordinates
			}
			count = 0;
		}
		control = false;
	}
	x.push_back(x[0]);
	y.push_back(y[0]);
	//Starting coordinates
}

/************************************************************
 ** Function:returnDirection
 ** Description:checks which direction user wants
 ** Parameters:int
 ** Pre-Conditions:int initialized
 ** Post-Conditions:player is moved accordingly
 ***********************************************************/
char returnDirection(int i) {
	char direction;
	if(i == 0) {
		cout << "Enter WASD for direction" << endl;
		cout << "------------------------" << endl;
	}
	else
		cout << "Enter direction to fire arrow" << endl;
	system("stty cbreak -echo");
	direction = getchar();
	system("stty cooked echo");
	return direction;
}

/************************************************************
 ** Function:keyPress
 ** Description:moves player in specified direction
 ** Parameters:vector<int> &, vector<int> &, int, vector<vector<Room>> &, int &
 ** Pre-Conditions:variables initialized
 ** Post-Conditions:player moved accordingly
 ***********************************************************/
void keyPress(vector<int> &x, vector<int> &y, int gridSize, vector<vector<Room>> &rooms, int &arrows) {
	char direction = returnDirection(0);
	if(direction == 'd') {
		if(y[0] + 1 < gridSize) {
			y[0] = y[0] + 1;
		}
	}
	else if(direction == 'w') {
		if(x[0] - 1 >= 0) {
			x[0] = x[0] - 1;
		}
	}
	else if(direction == 'a') {
		if(y[0] - 1 >= 0) {
			y[0] = y[0] - 1;
		}
	}
	else if(direction == 's') {
		if(x[0] + 1 < gridSize) {
			x[0] = x[0] + 1;
		}
	}
	else if(direction == ' ') {
		if(arrows != 0) {
			arrows--;
			arrow(x, y, rooms, gridSize);
			cout << arrows << " arrows remaining" << endl;
		}
	}
	else 
		cout << "Not a direction" << endl;
}

/************************************************************
 ** Function:generateRandom
 ** Description:generates random number from 0 to max - 1
 ** Parameters:int
 ** Pre-Conditions:max is not less than 0
 ** Post-Conditions:num between 0 to max - 1
 ***********************************************************/
int generateRandom(int max) {
	return (rand() % max);
}

/************************************************************
 ** Function:printScreen
 ** Description:prints grid to screen
 ** Parameters:int, vector<int> &, vector<int> &
 ** Pre-Conditions:variables initialized
 ** Post-Conditions:grid printed to screen
 ***********************************************************/
void printScreen(int gridSize, vector<int> &x, vector<int> &y) {
	string l1,l2,l3,l4;
	for(int i = 0; i < gridSize; i++) {
		l1 = "+", l2 = "|", l3 = "|", l4 = "|";
		for(int j = 0; j < gridSize; j++) {
			l1 = l1 + "---+";
			l2 = l2 + "   |";
			l3 = specialPrint(l3, x, y, i, j);
			l4 = l4 + "   |";
		}
		cout << l1 << endl << l2 << endl << l3 << endl << l4 << endl;
	}
	l1 = "+";
	for(int i = 0; i < gridSize; i++) {
		l1 = l1 + "---+";
	}
	cout << l1 << endl;
}

/************************************************************
 ** Function:printScreenRegular
 ** Description:prints to screen in non debug mode
 ** Parameters:int, vector<int> &, vector<int> &
 ** Pre-Conditions:variables initialized
 ** Post-Conditions:grid printed to screen
 ***********************************************************/
void printScreenRegular(int gridSize, vector<int> &x, vector<int> &y) {
	string l1,l2,l3,l4;
	for(int i = 0; i < gridSize; i++) {
		l1 = "+", l2 = "|", l3 = "|", l4 = "|";
		for(int j = 0; j < gridSize; j++) {
			l1 = l1 + "---+";
			l2 = l2 + "   |";
			if(i == x[0] && j == y[0]) {
				l3 = l3 + " * |"; 
			}
			else
				l3 = l3 + "   |";
			l4 = l4 + "   |";
		}
		cout << l1 << endl << l2 << endl << l3 << endl << l4 << endl;
	}
	l1 = "+";
	for(int i = 0; i < gridSize; i++) {
		l1 = l1 + "---+";
	}
	cout << l1 << endl;
}

/************************************************************
 ** Function:specialPrint
 ** Description:returns special string to print to screen based on event in room
 ** Parameters:string, vector<int> &, vector<int>  &, int, int
 ** Pre-Conditions:variables initialized
 ** Post-Conditions:string returned based on event
 ***********************************************************/
string specialPrint(string s, vector<int> &x, vector<int> &y, int i, int j) {
	if(i == x[0] && j == y[0]) {
		s = s + " * |"; 
	}
	else if((i == x[1] && j == y[1]) || (i == x[5] && j == y[5])) {
		s = s + " B |"; 
	}
	else if((i == x[2] && j == y[2]) || (i == x[6] && j == y[6])) {
		s = s + " P |"; 
	}
	else if(i == x[3] && j == y[3]) {
		s = s + " G |"; 
	}
	else if(i == x[4] && j == y[4]) {
		s = s + " W |"; 
	}
	else {
		s = s + "   |";
	}
	return s;
}

/************************************************************
 ** Function:populateEvents
 ** Description:Populates all events with their polymorphic objects
 ** Parameters:vector<int> &, vector<int> &, int, vector<vector<Room>> &
 ** Pre-Conditions:variables initialized
 ** Post-Conditions:events populated respectively
 ***********************************************************/
void populateEvents(vector<int> &x, vector<int> &y, int gridSize, vector< vector<Room> > &rooms) {
	for(int i = 0; i < gridSize; i++) {
		for(int j = 0; j < gridSize; j++) {	
			if((i == x[1] && j == y[1]) || (i == x[5] && j == y[5])) {
				rooms[i][j].set_event(1);
			}
			else if((i == x[2] && j == y[2]) || (i == x[6] && j == y[6])) {
				rooms[i][j].set_event(2);
			}
			else if(i == x[3] && j == y[3]) {
				rooms[i][j].set_event(3);
			}
			else if(i == x[4] && j == y[4]) {
				rooms[i][j].set_event(4);
			}
		}
	}
}





