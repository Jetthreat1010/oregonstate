#include <iostream>
#include <string>
#include <cstring>
#include <cstdlib>
#include <cmath>
#include <ctime>
#include <stdlib.h>

#include "gold.h"

using namespace std;

/************************************************************
 ** Function:percepts
 ** Description:returns percept of event
 ** Parameters:none
 ** Pre-Conditions:none
 ** Post-Conditions:returns percept
 ***********************************************************/
string Gold::percepts() {
	return "You see a glimmer nearby";
}

