#include <iostream>
#include <string>
#include <cstring>
#include <cstdlib>
#include <cmath>
#include <ctime>
#include <stdlib.h>

#include "pit.h"

using namespace std;

/************************************************************
 ** Function:percepts
 ** Description:polymorphic function to display according percept for event
 ** Parameters:none
 ** Pre-Conditions:none
 ** Post-Conditions:returns string of percept
 ***********************************************************/
string Pit::percepts() {
	return "You feel a breeze";
}

