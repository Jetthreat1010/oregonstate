/******************************************************
 * ** Program: event.h
 * ** Author: Lawson Dietz
 * ** Date: 11/25/2019
 * ** Description:abstract class for all events
 * ** Input:none
 * ** Output:none
 * ******************************************************/
#include <iostream>
#include <string>
#include <cstring>
#include <cstdlib>
#include <cmath>
#include <ctime>
#include <stdlib.h>

#ifndef EVENT_H
#define EVENT_H

using namespace std;

class Event {
	private:
		string percept = "Event";
	public:
		virtual string percepts() = 0;
};

#endif
