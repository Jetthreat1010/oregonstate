#include <iostream>
#include <string>
#include <cstring>
#include <cstdlib>
#include <cmath>
#include <ctime>
#include <stdlib.h>

#ifndef WUMPUS_H
#define WUMPUS_H
#include "event.h"

using namespace std;

class Wumpus : public Event {
	public:
		virtual string percepts() override;
};

#endif
