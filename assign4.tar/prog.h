#include <iostream>
#include <string>
#include <cstring>
#include <cstdlib>
#include <cmath>
#include <ctime>
#include <stdlib.h>
#include <algorithm>
#include <vector>

#ifndef PROG_H
#define PROG_H

#include "room.h"
#include "event.h"

using namespace std;

void fillVector(vector<vector<Room>> &, int);
bool win(vector<int> &, vector<int> &, bool &);
char returnDirection(int);
int notInt();
int generateRandom(int);
void batsRandom(vector<int> &, vector<int> &, int);
void printScreen(int, vector<int> &, vector<int> &);
void printScreenRegular(int, vector<int> &, vector<int> &);
void createVectorCoords(vector<int> &, vector<int> &, int);
string specialPrint(string, vector<int> &, vector<int> &, int, int);
void populateEvents(vector<int> &, vector<int> &, int, vector<vector<Room>> &);
void keyPress(vector<int> &, vector<int> &, int, vector<vector<Room>> &, int &);
void checkCoordinates(vector<int> &, vector<int> &, vector<vector<Room>> &, bool &, bool &, int);
void checkPercepts(vector<int> &, vector<int> &, vector<vector<Room>> &, int);
void arrow(vector<int> &, vector<int> &, vector<vector<Room>> &, int);
bool arrowW(vector<int> &, vector<int> &, vector<vector<Room>> &, int);
bool arrowA(vector<int> &, vector<int> &, vector<vector<Room>> &, int);
bool arrowS(vector<int> &, vector<int> &, vector<vector<Room>> &, int);
bool arrowD(vector<int> &, vector<int> &, vector<vector<Room>> &, int);
void moveWumpus(vector<int> &, vector<int> &, int, vector<vector<Room>> &);

#endif
