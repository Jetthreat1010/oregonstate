#include <iostream>
#include <string>
#include <cstring>
#include <cstdlib>
#include <cmath>
#include <ctime>
#include <stdlib.h>

#ifndef PIT_H
#define PIT_H
#include "event.h"

using namespace std;

class Pit : public Event {
	public:
		virtual string percepts() override;
};

#endif

