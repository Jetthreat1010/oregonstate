#include <iostream>
#include <string>
#include <cstring>
#include <cstdlib>
#include <cmath>
#include <ctime>
#include <stdlib.h>

#ifndef BATS_H
#define BATS_H
#include "event.h"

using namespace std;

class Bats : public Event {
	public:
		virtual string percepts() override;
};

#endif
