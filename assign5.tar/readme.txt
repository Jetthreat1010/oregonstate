Hey, thanks for grading my program. Everything should be there and I've done anything so I should not be losing any points for anything. I did the 
recursive selection sort for sort descending. As for regarding input for the main, the program assumes that only correct input is submitted. Since 
the rubric says nothing about accepting incorrect input, please don't enter incorrect input (just a string when int is asked for, and only the 2 
options given when prompted)as it will most likely seg fault. I didn't want to make a .h file for the main because I didn't need any functions for
the main. Thanks for grading my assignment and being an awesome TA, I enjoyed every single TA. 
