/******************************************************
 * ** Program:prog.cpp
 * ** Author: Lawson Dietz
 * ** Date: 12/7/2019
 * ** Description:Driver class for creating linked list
 * ** Input:none
 * ** Output:none
 * ******************************************************/
#include <iostream>

#include "node.h"
#include "linked_list.h"

using namespace std;

int main() {
	Linked_List l;
	string user;
	int number;
	bool control = true;
	bool runAgain = true;
	while(runAgain) {
		while(control) {
			cout << "Please enter a number: ";
			cin >> number;
			l.push_front(number);
			cout << "Do you want another number (y or n): ";
			cin >> user;
			if(user == "n")
				control = false;
		}
		cout << "Sort Ascending or descending (a or d): ";
		cin >> user;
		if(user == "a")
			l.sort_ascending();
		else if(user == "d")
			l.sort_descending();
		l.print();
		l.findPrimes();
		cout << "Do you want to do this again (y or n): ";
		cin >> user;
		if(user == "n")
			runAgain = false;
		l.clear();
		control = true;
	}
}
