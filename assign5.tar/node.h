#include <iostream>

#ifndef NODE_H
#define NODE_H

using namespace std;

class Node {
	public:
		int val;
		Node* next;
};

#endif
