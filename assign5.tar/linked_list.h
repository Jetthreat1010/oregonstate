#include <iostream>

#ifndef LINKED_LIST_H
#define LINKED_LIST_H

using namespace std;

class Linked_List {
	private:
		unsigned int length;
		Node *head;
	public:
		Linked_List();
		int get_length();
		void print();
		void clear();
		unsigned int push_front(int);
		unsigned int push_back(int);
		unsigned int insert(int, unsigned int);
		void sort_ascending();
		void sort_descending();
		void mergeSort(Node**);
		Node* mergeList(Node*, Node*);
		void splitList(Node*, Node**, Node**);
		void sortDescending(Node**);
		Node* selectionSort(Node*);
		void swapNodes(Node**, Node*, Node*, Node*);
		void findPrimes();
		bool isPrime(int);
		void deleteList(Node**);
};

#endif
